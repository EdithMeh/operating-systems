#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
//debes compilar con gcc hilos.c -o hilos –lpthread
//declaramos los prototipos de los hilos  (interface)
void *hiloA();
void *hiloB();
//implmentamos lo que haran los hilos
void *hiloA(){
 printf("soy el hilo A \n");
 fflush(stdout);//permite ver la impresion directa en pantalla 
 
 sleep(1);//retardamos un segundo
 }
void *hiloB(){
printf("soy el hilo B \n");
fflush(stdout);

}
int main(){
pthread_t hilo1;
pthread_t hilo2;
 pthread_create(&hilo1,NULL,hiloA,NULL);//creamos el primer hilo
 pthread_create(&hilo2,NULL,hiloB,NULL);//creamos el segundo hilo
  pthread_join(hilo1,NULL);
  pthread_join(hilo2,NULL);
}
