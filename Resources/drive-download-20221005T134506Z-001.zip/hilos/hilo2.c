#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
//debes compilar con gcc hilos.c -o hilos –lpthread
//declaramos los prototipos de los hilos  (interface)
#define NUM_THREADS     15
long t;

void *hiloA();
void *hiloB();
//implmentamos lo que haran los hilos
void *hiloA(){
 printf("soy el hilo A \n");
 fflush(stdout);//permite ver la impresion directa en pantalla 
 
 sleep(1);//retardamos un segundo
 }
void *hiloB(){
printf("soy el hilo B \n");
fflush(stdout);

}
int main(){
    pthread_t hilo1;
    pthread_t hilo2;
    
    for(t=0; t<NUM_THREADS; t++){
        pthread_create(&hilo1,NULL,hiloA,(void *)t);//creamos el primer hilo
        pthread_create(&hilo2,NULL,hiloB,(void *)t);//creamos el segundo hilo
        pthread_join(hilo1,NULL);
        pthread_join(hilo2,NULL);
    }
}
