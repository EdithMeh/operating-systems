#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>

#define CICLO 1000
static int contador = 0;

int turno, otro;
int interesado[2];

static void * hilo_1_funcion(void* arg)
{
    int i;

    printf("Incrementar...\n");
   
    for (i = 0; i <= CICLO; i++)
    {
        interesado[0]=1;
        turno=1;     
        while (interesado[1]==1 && turno==1)
        {
            //esperar
        }
        //printf("Proceso 0 entra a la region critica\n");
        contador = contador + 1;
        interesado[0]=0;
        
        //printf("turno es del proceso %d\n", turno);
        //sleep(1);       
    }
    
    
    printf("\n Hilo 1 Contador: %d\n", contador);
}

static void * hilo_2_funcion(void* arg)
{
    int i;

    printf("Decrementar...\n");
    
    for (i = 0; i <= CICLO; i++)
    {
        interesado[1] = 1;
        turno = 0;

        while (interesado[0]==1 && turno==0)
        {
            //esperar
        }

        //printf("Proceso 1 entra a la region critica \n");        
        contador = contador - 1;
        interesado[1]=0;
        //printf("turno es del proceso %d\n", turno);
        //sleep(1);      
    }
    
    printf("\n Hilo 2 Contador: %d\n", contador);
}

int main()
{
    pthread_t hilo_1, hilo_2;

    turno = 0;
    interesado[0]=0;
    interesado[1]=0;

    pthread_create(&hilo_1, NULL, *hilo_1_funcion, NULL);
    pthread_create(&hilo_2, NULL, *hilo_2_funcion, NULL);

    pthread_join(hilo_2, NULL);
    pthread_join(hilo_1, NULL);

    printf("\n Valor Contador: %d\n", contador);
    return 0;
}

