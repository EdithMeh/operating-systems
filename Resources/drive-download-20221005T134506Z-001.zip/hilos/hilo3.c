#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *mostrarTexto(void *data)
{
    char *texto = (char *) data;

    printf("%s\n", texto);        
}

int main(){
    pthread_t hilo1;
    pthread_t hilo2;
    int i = 0;

    while (i < 100)
//    while (1)
    {
         pthread_create(&hilo1,NULL,&mostrarTexto,"Hola Mundo");//creamos el primer hilo
         pthread_create(&hilo2,NULL,&mostrarTexto,"...................Adios Mundo");//creamos el segundo hilo

         i = i + 1;
//         sleep(5);
    }

         pthread_join(hilo1,NULL);
         pthread_join(hilo2,NULL);

}
