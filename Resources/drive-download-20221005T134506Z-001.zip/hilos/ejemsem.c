#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>

#define CICLO 100000000
static int contador = 0;

sem_t semaforo_1;

static void * hilo_1_funcion(void* arg)
{
    int i;

    for (i = 0; i <= CICLO; i++)
    {
        sem_wait(&semaforo_1);
        contador = contador + 1;
        sem_post(&semaforo_1);
    }
}

static void * hilo_2_funcion(void* arg)
{
    int i;

    for (i = 0; i <= CICLO; i++)
    {
        sem_wait(&semaforo_1);
        contador = contador - 1;
        sem_post(&semaforo_1);
    }
}

int main()
{
    pthread_t hilo_1, hilo_2;

    sem_init(&semaforo_1, 0, 1);

    pthread_create(&hilo_1, NULL, *hilo_1_funcion, NULL);
    pthread_create(&hilo_2, NULL, *hilo_2_funcion, NULL);

    pthread_join(hilo_1, NULL);
    pthread_join(hilo_2, NULL);

    printf("\n Valor Contador: %d\n", contador);
    return 0;
}

