#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int valor = 0;
//pthread_mutex_t mutex;

void *incrementarValor();

void *incrementarValor()
{
    int i;
     
    for (i=0; i< 200000000; i++)
    {
//         pthread_mutex_lock(&mutex);
         valor = valor + 1;
//         pthread_mutex_unlock(&mutex);
    }
    sleep(15);
}

int main(){
    pthread_t hilo1;
    pthread_create(&hilo1,NULL,incrementarValor,NULL);//creamos el primer hilo

    pthread_t hilo2;
    pthread_create(&hilo2,NULL,incrementarValor,NULL);//creamos el segundo hilo
    pthread_join(hilo1,NULL);
    pthread_join(hilo2,NULL);

    printf("Valor = %d\n", valor);
    
    return EXIT_SUCCESS; 
}
