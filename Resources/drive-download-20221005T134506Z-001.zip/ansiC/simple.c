/*
* simple.c - Programa ejemplo ncurses
*/
#include <stdlib.h>
#include <curses.h>

int main(void)
{
	initscr();
	refresh();
	printw("Hola Mundo");
	refresh();
	sleep(3);
	endwin();
	return 0;
}
