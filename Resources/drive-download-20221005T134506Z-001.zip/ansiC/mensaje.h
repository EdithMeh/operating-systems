/*
* mensaje.h - Encabezado de mensaje.c
*/
void imprimir_mensaje(char *mensaje);
