/*
* hola.c - Programa "Hello, World!"
*/
#include <stdio.h>

int main(void)
{
	printf("Hola Mundo!\n");
	
	return 0;
}
