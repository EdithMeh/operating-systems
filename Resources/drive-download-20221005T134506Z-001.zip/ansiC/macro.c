/*
* macro: Macro con valor
*
*/

#include <stdio.h>

int main (void)
{
    printf ("Valor de NUM es %d\n", NUM);
    return 0;
}
