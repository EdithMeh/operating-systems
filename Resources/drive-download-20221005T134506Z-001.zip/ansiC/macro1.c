/*
* macro1: Ejemplo Macros
* 
*/

#include <stdio.h>

int main (void)
{
    #ifdef TEST
        int i=1;
	printf("Prueba Macro\n");
    #endif
    printf ("Prueba\n");
    return 0;
}
