/*
* mensaje.c - Implementacion de la funcion imprimir_mensaje()
*/
#include <stdio.h>
#include "mensaje.h"

void imprimir_mensaje(char *mensaje)
{
	printf("%s\n", mensaje);
}
